import React from 'react'
import Footer from './components/Footer/Footer'
import Header from './components/Header/Header'

export default function Layout({children}) {
   return (
      <>
      <div className="body-wrapper">
      <Header />
      {children}
      <div className="preloader" id="preloader">
        <div className="preloader-inner">
            <div className="spinner">
                <div className="dot1"></div>
                <div className="dot2"></div>
            </div>
        </div>
    </div>
    <Footer />
    </div>
      </>
   )
}
