import Layout from '../components/Layout/Layout';
import React from "react";
import ReactDOM from "react-dom";
import Head from "next/head";
import Router from "next/router";



Router.events.on("routeChangeStart", (url) => {
  console.log(`Loading: ${url}`);
  document.body.classList.add("body-page-transition");
  ReactDOM.render(
    <PageChange path={url} />,
    document.getElementById("page-transition")
  );
});
Router.events.on("routeChangeComplete", () => {
  ReactDOM.unmountComponentAtNode(document.getElementById("page-transition"));
  document.body.classList.remove("body-page-transition");
});
Router.events.on("routeChangeError", () => {
  ReactDOM.unmountComponentAtNode(document.getElementById("page-transition"));
  document.body.classList.remove("body-page-transition");
});


function MyApp({ Component, pageProps }) {
  return (
    <React.Fragment>
    <><Head>
      <meta name="viewport" content="viewport-fit=cover" />
      <link href="css/responsive.css" rel="stylesheet" />
      <link href="css/font-icons.css" rel="stylesheet" />
      <link href="css/plugins.css" rel="stylesheet" />
      <link href="css/style.css" rel="stylesheet" />
    </Head><Layout>
        <Component {...pageProps} />
      </Layout></>
      </React.Fragment>
  );
}

export default MyApp
